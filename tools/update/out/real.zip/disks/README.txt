The Mac's disk images: hard disks and floppies (.dsk .img .image .hfv .hda), CD-ROMs (.iso .toast). See README.txt.
